# Inference Notes

**Model**: Grok Imagine (xAI)

**Prompt Processing**:
- Each prompt from prompts.txt submitted as-is.
- No negative prompts used.
- Style defaults to high-quality, detailed output.
- Aspect ratio: mostly square / landscape as natural for scene.

**Generation Process**:
1. Load prompt.
2. Submit to Grok Imagine text-to-image.
3. Receive image with watermark.
4. Save as prompt_XX.png in generated_images/.
5. Log any visible artifacts.

**Observed Behavior**:
- Strong adherence to descriptive prompts.
- Excellent color and lighting fidelity for landscapes and nature.
- Sci-fi and abstract scenes render creatively.
- Animals generally accurate; rare minor anatomical issues.
- No refusals on any of the 35 prompts.

**Environment**:
- Date of generation: September 2026
- Platform: Grok / xAI
- No local GPU required; remote inference.

**Reproducibility**:
- Seeds not fixed (stochastic generation).
- Same prompt may yield variations on re-run.